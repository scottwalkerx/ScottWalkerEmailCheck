import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern; 

/* This program is designed to validate emails*/


public class emailCheck {

	private Pattern pattern;
	private Matcher  matcher;
	
	/* this string checks the email only has acceptable characters */
	 private static final String emailVal = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
	            + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	
	 public emailCheck()
	    {    pattern = Pattern.compile(emailVal);    }
	 
	 public boolean validation(final String email)
	    {
	        matcher = pattern.matcher(email);
	        return matcher.matches();
	    }
	 
	 
	 
	public static void main(String[] args) {
		
		/*importing a list of emails to validate */
		ArrayList<String> validEmailList = new ArrayList<>();
        validEmailList.add("scott@hcl.com");
        validEmailList.add("scott@yahoo.net");
        validEmailList.add("scott.50@yahoo.x");
        
        /* creating new object so constructor can compile for new emails*/
        emailCheck emailCheck = new emailCheck();
        
        
        /* print the results of the email validation*/
        for (String email : validEmailList)
        {
            System.out.println(email + " is Valid = " + emailCheck.validation(email));
        }
        
	}

}
